Project's Purpose: My Project's purpose is to compile and showcase my College Projects and achievements and also the challenges I have faced in my CCS 
journey in TIP.so that I may use it to showcase my talent to my colleagues, instructors and hopefully Job Recruiters. 
I also aspire to "Personalize" my own portfolio so that it may look interactive, friendly and really maintained often, which is what I plan to do.

Technologies Used: 
HTML to build the main backbone of my website
CSS  to add embellishments and flair to the html so that my website would look pleasing to the eye
JavaScript to add an interactive technology. In my case, I used icons and made it so that when I clicked the icons it leads to the corresponding social
media profile link provided.

addons used -
font awesome : https://fontawesome.com/icons
google fonts Fjalla One: https://fonts.google.com/?query=fjalla

google fonts has provided me their code in order to apply their font to my own codes:  

    <link rel="stylesheet" href="KURT ZILDJIAN SANTOS CITE-001.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fjalla+One&display=swap" rel="stylesheet">

Stack Overflow, htmlw3schools, openAI were all used to help me get a general grasp of the concepts of html, css and JS so that i may apply what kind of 
project i conceptualized in my mind.I also used it to troubleshoot complex errors and to help me in applying JavaScript. 
Github - you can refer to my github repository (this is my first project hehe) https://github.com/porogami63/ideal-pancake



all of these technologies has helped me produce an output that I am confident in.




- Santos, Kurt Zildjian C. || CITE 001 || MON // WED || Mr. Eli Sagsagat







